/* Browser platform for id Software DOOM. GPL-2.0, see LICENSE. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <emscripten.h>
#include "doomdef.h"
#include "doomstat.h"
#include "d_event.h"
#include "d_main.h"
#include "d_net.h"
#include "i_system.h"
#include "i_video.h"
#include "i_sound.h"
#include "v_video.h"
#include "w_wad.h"
#include "z_zone.h"
#include "m_misc.h"

static byte palette[768];
static unsigned char rgba[SCREENWIDTH * SCREENHEIGHT * 4];

EMSCRIPTEN_KEEPALIVE void doom_key(int down, int key) {
    event_t e = {0}; e.type = down ? ev_keydown : ev_keyup;
    e.data1 = key; D_PostEvent(&e);
}
EMSCRIPTEN_KEEPALIVE void doom_mouse(int buttons, int dx, int dy) {
    event_t e = {0}; e.type = ev_mouse; e.data1=buttons;
    e.data2=dx*4; e.data3=-dy*4; D_PostEvent(&e);
}
EM_JS(void, web_init, (), {
    var c=Module.canvas; c.width=320; c.height=200;
    Module.ctx=c.getContext('2d'); Module.image=Module.ctx.createImageData(320,200);
    Module.buttons=0; var held=new Set();
    var keys={ArrowUp:173,ArrowDown:175,ArrowLeft:172,ArrowRight:174,
      KeyW:173,KeyS:175,KeyA:44,KeyD:46,ControlLeft:157,ControlRight:157,
      ShiftLeft:182,ShiftRight:182,AltLeft:184,AltRight:184,
      Enter:13,NumpadEnter:13,Escape:27,Space:32,Tab:9,Backspace:127,
      F1:187,F2:188,F3:189,F4:190,F5:191,F6:192,F7:193,F8:194,F9:195,F10:196,F11:215,F12:216,
      Pause:255,Equal:61,Minus:45,Comma:44,Period:46};
    function translate(e){if(keys[e.code]!==undefined)return keys[e.code];
      if(e.key && e.key.length===1)return e.key.toLowerCase().charCodeAt(0);return null;}
    function release(){held.forEach(function(k){_doom_key(0,k);});held.clear();Module.buttons=0;_doom_mouse(0,0,0);}
    if(typeof window!=='undefined') {
      window.addEventListener('keydown',function(e){
        if(document.activeElement!==c && document.pointerLockElement!==c)return;
        var k=translate(e);if(k===null)return;e.preventDefault();
        if(!held.has(k)){held.add(k);_doom_key(1,k);}
      });
      window.addEventListener('keyup',function(e){var k=translate(e);if(held.has(k)){e.preventDefault();held.delete(k);_doom_key(0,k);}});
      window.addEventListener('blur',release);c.addEventListener('blur',release);
      c.addEventListener('contextmenu',function(e){e.preventDefault();});
      c.addEventListener('mousedown',function(e){c.focus();if(document.pointerLockElement!==c)return;
        e.preventDefault();Module.buttons|=(e.button===0?1:e.button===2?2:4);_doom_mouse(Module.buttons,0,0);});
      window.addEventListener('mouseup',function(e){Module.buttons&=~(e.button===0?1:e.button===2?2:4);_doom_mouse(Module.buttons,0,0);});
      window.addEventListener('mousemove',function(e){if(document.pointerLockElement===c)_doom_mouse(Module.buttons,e.movementX,e.movementY);});
      document.addEventListener('visibilitychange',function(){if(document.hidden)release();});
    }
});
EM_JS(void, web_frame, (const unsigned char *data), {
    Module.image.data.set(HEAPU8.subarray(data,data+320*200*4));
    Module.ctx.putImageData(Module.image,0,0);
    if(!Module.firstFrame){Module.firstFrame=true;if(Module.onGameReady)Module.onGameReady();}
    if(Module.onDoomFrame)Module.onDoomFrame(Module.image.data);
});
void I_InitGraphics(void){web_init();}
void I_ShutdownGraphics(void){}
void I_SetPalette(byte *p){int i;for(i=0;i<768;i++)palette[i]=gammatable[usegamma][p[i]];}
void I_UpdateNoBlit(void){}
void I_FinishUpdate(void){int i;for(i=0;i<SCREENWIDTH*SCREENHEIGHT;i++){
 int n=screens[0][i]*3;rgba[i*4]=palette[n];rgba[i*4+1]=palette[n+1];rgba[i*4+2]=palette[n+2];rgba[i*4+3]=255;
}web_frame(rgba);}
void I_ReadScreen(byte *s){memcpy(s,screens[0],SCREENWIDTH*SCREENHEIGHT);}
void I_StartFrame(void){}
void I_StartTic(void){}

void I_InitNetwork(void){doomcom=calloc(1,sizeof(*doomcom));doomcom->id=DOOMCOM_ID;
 doomcom->ticdup=1;doomcom->numnodes=1;doomcom->numplayers=1;doomcom->consoleplayer=0;
 doomcom->deathmatch=0;netgame=false;}
void I_NetCmd(void){}

EM_JS(void, audio_init, (), {
    Module.soundHandles={};Module.nextSound=1;
    if(typeof window==='undefined')return;
    var AC=window.AudioContext||window.webkitAudioContext;
    if(!AC)return;
    Module.audio=new AC();
    function unlock(){if(Module.audio.state==='suspended')Module.audio.resume().catch(function(){});}
    window.addEventListener('pointerdown',unlock);window.addEventListener('keydown',unlock);
});
EM_JS(int, audio_play, (const byte *p,int len,int rate,int vol,int sep,int pitch), {
    var a=Module.audio;if(!a||a.state!=='running'||len<=0)return 0;
    var b=a.createBuffer(1,len,rate),out=b.getChannelData(0);
    for(var i=0;i<len;i++)out[i]=(HEAPU8[p+i]-128)/128;
    var src=a.createBufferSource(),g=a.createGain();src.buffer=b;
    src.playbackRate.value=Math.pow(2,(pitch-128)/64);g.gain.value=vol/15;
    var pan=a.createStereoPanner();pan.pan.value=Math.max(-1,Math.min(1,(sep-128)/128));
    src.connect(g);g.connect(pan);pan.connect(a.destination);
    var h=Module.nextSound++;Module.soundHandles[h]={src:src,gain:g,pan:pan};
    src.onended=function(){delete Module.soundHandles[h];src.disconnect();g.disconnect();pan.disconnect();};src.start();return h;
});
EM_JS(void,audio_stop,(int h),{var s=Module.soundHandles[h];if(s){s.src.stop();delete Module.soundHandles[h];}});
EM_JS(int,audio_playing,(int h),{return Module.soundHandles[h]?1:0;});
EM_JS(void,audio_params,(int h,int vol,int sep,int pitch),{var s=Module.soundHandles[h];if(s){s.gain.gain.value=vol/15;s.pan.pan.value=Math.max(-1,Math.min(1,(sep-128)/128));s.src.playbackRate.value=Math.pow(2,(pitch-128)/64);}});
void I_InitSound(void){audio_init();}
void I_UpdateSound(void){} void I_SubmitSound(void){} void I_ShutdownSound(void){}
void I_SetChannels(void){}
int I_GetSfxLumpNum(sfxinfo_t *sfx){if(sfx->link)sfx=sfx->link;char name[16];snprintf(name,sizeof(name),"ds%s",sfx->name);return W_GetNumForName(name);}
int I_StartSound(int id,int vol,int sep,int pitch,int priority){
 sfxinfo_t *s=&S_sfx[id];if(s->link)s=s->link;
 int lump=I_GetSfxLumpNum(s),n=W_LumpLength(lump);byte *p=W_CacheLumpNum(lump,PU_CACHE);
 if(n<8||p[0]!=3||p[1]!=0)return 0;int rate=p[2]|p[3]<<8;unsigned int len=p[4]|p[5]<<8|p[6]<<16|((unsigned int)p[7]<<24);
 if(rate<1)return 0;if(len>(unsigned int)n-8)len=n-8;
 return audio_play(p+8,len,rate,vol,sep,pitch);
}
void I_StopSound(int h){audio_stop(h);}int I_SoundIsPlaying(int h){return audio_playing(h);}
void I_UpdateSoundParams(int h,int vol,int sep,int pitch){audio_params(h,vol,sep,pitch);}
/* MUS music needs a synthesizer; this port implements PCM effects only. */
void I_InitMusic(void){}void I_ShutdownMusic(void){}void I_SetMusicVolume(int v){}
void I_PauseSong(int h){}void I_ResumeSong(int h){}int I_RegisterSong(void *p){return 1;}
void I_PlaySong(int h,int loop){}void I_StopSong(int h){}void I_UnRegisterSong(int h){}
